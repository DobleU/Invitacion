# Full Screen Video with Parallax Scrolling

A Pen created on CodePen.

Original URL: [https://codepen.io/markhillard/pen/ogbmed](https://codepen.io/markhillard/pen/ogbmed).

This is a responsive layout that features a full screen "hero" video with a hardware accelerated parallax scrolling effect. You can play/pause the video at any time, set different scroll rates to as many elements as you like as well as add additional CSS transitions using jQuery.