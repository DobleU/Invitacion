# Interactive Magic Wand Cursor with Falling Star Effects

A Pen created on CodePen.

Original URL: [https://codepen.io/Kuutti-Siitonen/pen/KKJeOoQ](https://codepen.io/Kuutti-Siitonen/pen/KKJeOoQ).

This Pen demonstrates an interactive cursor effect where stars follow the mouse movement, creating a trail effect. As the cursor moves, stars are generated at the cursor's position with initial velocities influenced by the cursor's motion. These stars change color over time, transitioning from light yellow to bright orange, then to dark red, and finally to dark brown. Initially, each star appears at twice its final size and gradually shrinks to its normal size over a period of two seconds. The effect is achieved using HTML for structure, CSS for styling, and JavaScript for dynamic behavior and animation. The JavaScript code calculates mouse velocity, applies gravity, drag, and turbulence to the star's motion, and manages their lifecycle and color transitions.

(By ChatGPT)