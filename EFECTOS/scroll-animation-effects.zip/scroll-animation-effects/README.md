# Scroll animation effects

A Pen created on CodePen.

Original URL: [https://codepen.io/jspeer/pen/wjGREo](https://codepen.io/jspeer/pen/wjGREo).

Trying out various 'documentary' style effects on page scroll. The plan was to use web animations and transitions instead of animated gifs or videos for a more documentary styled effect.