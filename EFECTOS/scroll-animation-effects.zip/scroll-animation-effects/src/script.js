/* DRIVEN
 * https://www.uwlax.edu/story/driven/
*/
$('.pan-horizontal-continual .contentblock p').after($('.pan-horizontal-continual .contentblock p').clone());
/* Site Scrolling effects ======================================================================================*/
function siteScrollEffects() {
	$(".anim-on-screen").addClass("active");
	$(".anim-on-screen.active").each(function (i, el) {
		if ($(el).inViewport(true) && !$(el).hasClass("on-screen")) {
			$(el).addClass("on-screen")
		}
		if ($(el).inViewport(true)) {
			//Check to see which animation is in viewport and run a function
			if ($(el).hasClass("feature-image-1")) {
				animFeature1($(el));
			} else if ($(el).hasClass("feature-image-2")) {
				animFeature2($(el));
			} else if ($(el).hasClass("feature-image-3")) {
				animFeature3($(el));
			} else if ($(el).hasClass("feature-image-4")) {
				animFeature4($(el));
			} else if ($(el).hasClass("feature-image-5")) {
				animFeature5($(el));
			} else if ($(el).hasClass("feature-image-6")) {
				animFeature6($(el));
			} else if ($(el).hasClass("cover-photo")) {
				coverPhoto($(el));
			}
		} else {
			if ($(el).hasClass("cover-photo")) {
				$(el).removeClass("stick");
			}
		}
	});
}
function animFeature1(el) {
	zoomOnScroll(el.find(".contentblock"), 3);
}
function animFeature2(el) {
}
function animFeature3(el) {
	zoomOnScroll(el.find(".contentblock"), 3);
}
function animFeature4(el) {
	zoomOnScroll(el.find(".contentblock"), 4);
}
function animFeature5(el) {
	zoomOnScroll(el.find(".imagefile"), 4);
}
function animFeature6(el) {
	fadeInOnScroll(el.find(".imagefile"), el.find(".imagefile"), 1);
	fadeInOnScroll(el.find(".contentblock"), el.find(".imagefile"), 2);
}
function coverPhoto(el) {
	fadeOutOnScroll(el.find(".imagefile"),el.find(".imagefile"), 1);
	fadeOutOnScroll(el.find(".contentblock"),el.find(".imagefile"), 2);
	stickOnScroll(el.find(".contentblock"));
}

function fadeOutOnScroll(el,parent,speed) {
	var scroll = $(window).scrollTop(),
		imgOffset = parent.offset().top,
		imgHeight = parent.outerHeight(),
		windowHeight = $(window).outerHeight(),
		theModifier = (((imgHeight/speed) - (scroll - imgOffset)) / (imgHeight/speed));
	el.css("opacity", theModifier);
	/*console.log(
	' scroll: ' + scroll
	+ ' imgOffset: ' + imgOffset
	+ ' imgHeight: ' + imgHeight
	+ ' theModifier: ' + theModifier
	*/
}
function fadeInOnScroll(el, parent, speed) {
	var scroll = $(window).scrollTop(),
		imgOffset = parent.offset().top,
		imgHeight = parent.outerHeight(),
		windowHeight = $(window).outerHeight(),
		//theModifier = (imgHeight / speed) / ((scroll - imgOffset));
		theModifier = (scroll+(windowHeight / (2/speed))-imgOffset)/(imgHeight);
	if(theModifier >= 1){
		theModifier = 1;
	}
	el.css("opacity", theModifier);
	console.log(
	' scroll: ' + scroll
	+ ' speed: ' + speed
	+ ' imgOffset: ' + imgOffset
	+ ' imgHeight: ' + imgHeight
	+ ' theModifier: ' + theModifier
	);
}

function stickOnScroll(el) {
	var scroll = $(window).scrollTop(),
		imgOffset = el.parent().offset().top,
		imgHeight = el.parent().outerHeight(),
		windowHeight = $(window).outerHeight(),
		theModifier = (((imgHeight) - (scroll - imgOffset)) / (imgHeight));
	if ((scroll - imgOffset) >= 0) {
		el.addClass("stick");
	} else {
		el.removeClass("stick");
	}
}

function zoomOnScroll(el, speed) {
	var scroll = $(window).scrollTop(),
		imgOffset = el.parent().offset().top,
		imgHeight = el.parent().outerHeight(),
		windowHeight = $(window).outerHeight(),
		minSize = 1,
		maxSize = 1.3,
		theModifier = (minSize + ((scroll + (windowHeight / 4)) - imgOffset) / (imgHeight * speed)).toFixed(4);

	if (theModifier <= minSize) {
		theModifier = minSize;
	} else if (theModifier >= maxSize) {
		theModifier = maxSize;
	}
	el.css("transform", "scale(" + theModifier + ")");
	return theModifier;
}

//Determine if items are in the viewport and if so, add a class for animations
(function ($) {
	$.fn.inViewport = function (partial) {
		var $t = $(this),
			$w = $(window),
			viewTop = $w.scrollTop(),
			viewBottom = viewTop + $w.height(),
			_top = $t.offset().top,
			_bottom = _top + $t.height(),
			compareTop = partial === true ? _bottom : _top,
			compareBottom = partial === true ? _top : _bottom;

		return compareBottom <= viewBottom && compareTop >= viewTop;
	};
})(jQuery);

$(window).scroll(function () {
	siteScrollEffects();
});

siteScrollEffects();
