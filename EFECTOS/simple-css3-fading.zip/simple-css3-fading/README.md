# Simple CSS3 Fading

A Pen created on CodePen.

Original URL: [https://codepen.io/superchief/pen/mJmoBz](https://codepen.io/superchief/pen/mJmoBz).

This is sort of a CSS3 splash fading thing. No script just CSS3 animations for a simple effect. Use the transitions to play with different effects and the animation delays