# Simple letter-spacing text effect

A Pen created on CodePen.

Original URL: [https://codepen.io/dbj/pen/Zpvarx](https://codepen.io/dbj/pen/Zpvarx).

