# Zoom Blur Slider (scroll/click)

A Pen created on CodePen.

Original URL: [https://codepen.io/soju22/pen/poboddv](https://codepen.io/soju22/pen/poboddv).

This Zoom Blur effect is made with a shader from https://github.com/evanw/glfx.js

Quite simple, but I really like the transitions. Move your mouse :)
